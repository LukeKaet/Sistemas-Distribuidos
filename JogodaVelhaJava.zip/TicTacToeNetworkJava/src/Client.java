import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.net.Socket;

public class Client extends JFrame {
    private JTextField ipField = new JTextField("127.0.0.1");
    private JTextField portField = new JTextField("5000");
    private JButton connectBtn = new JButton("Conectar");
    private JLabel youAreLabel = new JLabel("Você é: -");
    private JLabel turnLabel = new JLabel("Vez de: -");
    private JLabel scoreLabel = new JLabel("Placar — X:0  O:0  Empates:0");
    private JTextArea msgArea = new JTextArea(4, 30);
    private JButton[][] cells = new JButton[3][3];
    private volatile char myMark = '-';
    private volatile char currentTurn = '-';
    private Socket socket; private PrintWriter out; private BufferedReader in;

    public static void main(String[] args) { SwingUtilities.invokeLater(Client::new); }

    public Client() {
        super("Cliente — Jogo da Velha");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        JPanel top = new JPanel(new GridLayout(2, 1, 6, 6));
        JPanel conn = new JPanel(new GridLayout(1, 5, 6, 6));
        conn.add(new JLabel("IP:")); conn.add(ipField);
        conn.add(new JLabel("Porta:")); conn.add(portField);
        conn.add(connectBtn); top.add(conn);

        JPanel info = new JPanel(new GridLayout(1, 3, 6, 6));
        info.add(youAreLabel); info.add(turnLabel); info.add(scoreLabel); top.add(info);
        add(top, BorderLayout.NORTH);

        JPanel board = new JPanel(new GridLayout(3, 3, 4, 4));
        Font f = new Font(Font.SANS_SERIF, Font.BOLD, 36);
        for (int r=0;r<3;r++){
            for (int c=0;c<3;c++){
                int rr=r, cc=c; JButton b=new JButton(" "); b.setFont(f);
                b.addActionListener((ActionEvent e)->play(rr,cc));
                cells[r][c]=b; board.add(b);
            }
        }
        add(board, BorderLayout.CENTER);

        msgArea.setEditable(false); msgArea.setLineWrap(true); msgArea.setWrapStyleWord(true);
        add(new JScrollPane(msgArea), BorderLayout.SOUTH);

        connectBtn.addActionListener(e->connect());

        setSize(500, 520); setLocationRelativeTo(null); setVisible(true);
    }

    private void connect(){
        String ip = ipField.getText().trim(); int port = Integer.parseInt(portField.getText().trim());
        connectBtn.setEnabled(false);
        new Thread(()->{
            try{
                socket = new Socket(ip, port);
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(),"UTF-8"), true);
                in  = new BufferedReader(new InputStreamReader(socket.getInputStream(),"UTF-8"));
                appendMsg("Conectado. Aguardando atribuição de marcador...");
                new Thread(this::readLoop, "Reader").start();
            }catch(IOException ex){
                SwingUtilities.invokeLater(()->{ JOptionPane.showMessageDialog(this,"Falha ao conectar: "+ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE); connectBtn.setEnabled(true); });
            }
        },"Connector").start();
    }

    private void readLoop(){
        try{
            String line;
            while((line=in.readLine())!=null){
                final String msg=line.trim();
                SwingUtilities.invokeLater(()->handleMessage(msg));
            }
        }catch(IOException e){
            SwingUtilities.invokeLater(()->appendMsg("Conexão encerrada."));
        }finally{
            try{ if(socket!=null) socket.close(); }catch(IOException ignored){}
            SwingUtilities.invokeLater(()->connectBtn.setEnabled(true));
        }
    }

    private void handleMessage(String msg){
        if(msg.startsWith("FULL")){ appendMsg("Servidor lotado (já há 2 jogadores)."); return; }
        if(msg.startsWith("ASSIGNED")){
            String[] parts=msg.split("\\s+"); if(parts.length==2){ myMark=parts[1].charAt(0);
                youAreLabel.setText("Você é: "+myMark); setTitle("Cliente — Jogo da Velha ("+myMark+")"); appendMsg("Você jogará como "+myMark+"."); }
            return;
        }
        if(msg.startsWith("BOARD")){
            String[] parts=msg.split("\\s+"); if(parts.length==2 && parts[1].length()==9){
                String b=parts[1]; for(int i=0;i<9;i++){ int r=i/3, c=i%3; char ch=b.charAt(i); cells[r][c].setText(String.valueOf(ch==' ' ? ' ' : ch)); }
            } return;
        }
        if(msg.startsWith("TURN")){
            String[] parts=msg.split("\\s+"); if(parts.length==2){ currentTurn=parts[1].charAt(0); turnLabel.setText("Vez de: "+currentTurn); } return;
        }
        if(msg.startsWith("SCORE")){
            String[] p=msg.split("\\s+"); if(p.length==4){ scoreLabel.setText("Placar — X:"+p[1]+"  O:"+p[2]+"  Empates:"+p[3]); } return;
        }
        if(msg.startsWith("WIN")){
            String[] p=msg.split("\\s+"); if(p.length==2){ char winner=p[1].charAt(0);
                if(winner==myMark) JOptionPane.showMessageDialog(this,"Você venceu! 🎉","Resultado",JOptionPane.INFORMATION_MESSAGE);
                else JOptionPane.showMessageDialog(this,"Você perdeu! 😓","Resultado",JOptionPane.INFORMATION_MESSAGE);
            } return;
        }
        if(msg.startsWith("DRAW")){ JOptionPane.showMessageDialog(this,"Empate! 🤝","Resultado",JOptionPane.INFORMATION_MESSAGE); return; }
        if(msg.startsWith("MSG")){ appendMsg(msg.substring(3).trim()); }
    }

    private void play(int r,int c){
        if(out==null){ appendMsg("Ainda não conectado."); return; }
        String cellText = cells[r][c].getText();
        if(!" ".equals(cellText)){ appendMsg("Casa já ocupada."); return; }
        if(currentTurn!=myMark){ appendMsg("Aguarde seu turno."); return; }
        out.println("MOVE "+r+" "+c);
    }

    private void appendMsg(String s){ msgArea.append(s+"\n"); msgArea.setCaretPosition(msgArea.getDocument().getLength()); }
}
