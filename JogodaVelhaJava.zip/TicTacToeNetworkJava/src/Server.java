import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * <h1>Servidor do Jogo da Velha (Tic-Tac-Toe) — 2 jogadores, TCP</h1>
 *
 * [documentação completa como enviada anteriormente]
 */
public class Server {

    private static final int PORT = 5000;
    private final char[][] board = new char[3][3];
    private char currentPlayer = 'X';
    private int xWins = 0, oWins = 0, draws = 0;
    private final java.util.List<ClientHandler> clients = new java.util.concurrent.CopyOnWriteArrayList<>();
    private final java.util.Map<Character, ClientHandler> playerMap = new java.util.concurrent.ConcurrentHashMap<>();
    private final Object lock = new Object();

    public static void main(String[] args) { new Server().start(); }

    private void start() {
        resetBoard();
        String localIp = resolveLocalIp();
        System.out.println("=== Servidor Jogo da Velha ===");
        System.out.println("IP local: " + localIp + "  | Porta: " + PORT);
        System.out.println("Aguarde conexões (máximo 2 jogadores)...");
        try (java.net.ServerSocket serverSocket = new java.net.ServerSocket(PORT)) {
            while (true) {
                java.net.Socket socket = serverSocket.accept();
                if (clients.size() >= 2) {
                    try (java.io.PrintWriter out = new java.io.PrintWriter(socket.getOutputStream(), true)) {
                        out.println("FULL");
                    } catch (Exception ignored) {}
                    socket.close();
                    continue;
                }
                char assigned = assignMark();
                ClientHandler handler = new ClientHandler(socket, assigned);
                clients.add(handler);
                playerMap.put(assigned, handler);
                handler.start();
                if (clients.size() == 2) {
                    broadcast("START");
                    sendFullStateToAll();
                }
            }
        } catch (java.io.IOException e) {
            System.err.println("Erro no servidor: " + e.getMessage());
        }
    }

    private char assignMark() { return playerMap.containsKey('X') ? 'O' : 'X'; }

    private void resetBoard() { synchronized (lock) { for (int r=0;r<3;r++) java.util.Arrays.fill(board[r],' ');} }

    private boolean isValidMove(int r,int c){return r>=0&&r<3&&c>=0&&c<3&&board[r][c]==' ';}

    private boolean checkWin(char p){
        for(int i=0;i<3;i++){ if(board[i][0]==p&&board[i][1]==p&&board[i][2]==p) return true;
                              if(board[0][i]==p&&board[1][i]==p&&board[2][i]==p) return true; }
        if(board[0][0]==p&&board[1][1]==p&&board[2][2]==p) return true;
        if(board[0][2]==p&&board[1][1]==p&&board[2][0]==p) return true;
        return false;
    }

    private boolean isBoardFull(){ for(int r=0;r<3;r++) for(int c=0;c<3;c++) if(board[r][c]==' ') return false; return true; }

    private String boardAsString(){ StringBuilder sb=new StringBuilder(9); for(int r=0;r<3;r++) for(int c=0;c<3;c++) sb.append(board[r][c]); return sb.toString(); }

    private void sendFullStateToAll(){
        String b=boardAsString();
        broadcast("ASSIGN "+(playerMap.containsKey('X')?"X":"-"));
        broadcast("ASSIGN "+(playerMap.containsKey('O')?"O":"-"));
        broadcast("BOARD "+b);
        broadcast("TURN "+currentPlayer);
        broadcast("SCORE "+xWins+" "+oWins+" "+draws);
        broadcast("MSG Jogo iniciado. Vez de "+currentPlayer);
    }

    private void nextPlayer(){ currentPlayer = (currentPlayer=='X') ? 'O' : 'X'; }

    private void broadcast(String msg){ for(ClientHandler ch:clients) ch.send(msg); }

    private void removeClient(ClientHandler ch){ clients.remove(ch); playerMap.values().removeIf(v->v==ch); broadcast("MSG Um jogador saiu. Aguardando reconexão..."); }

    private String resolveLocalIp(){
        try{
            java.util.Enumeration<java.net.NetworkInterface> ifaces = java.net.NetworkInterface.getNetworkInterfaces();
            while(ifaces.hasMoreElements()){
                java.net.NetworkInterface ni = ifaces.nextElement();
                if(!ni.isUp()||ni.isLoopback()||ni.isVirtual()) continue;
                java.util.Enumeration<java.net.InetAddress> addrs = ni.getInetAddresses();
                while(addrs.hasMoreElements()){
                    java.net.InetAddress ia = addrs.nextElement();
                    if(ia instanceof java.net.Inet4Address && !ia.isLoopbackAddress()) return ia.getHostAddress();
                }
            }
            return java.net.InetAddress.getLocalHost().getHostAddress();
        }catch(Exception e){ return "127.0.0.1"; }
    }

    private class ClientHandler extends Thread{
        private final java.net.Socket socket;
        private final char mark;
        private java.io.PrintWriter out;
        private java.io.BufferedReader in;

        ClientHandler(java.net.Socket socket, char mark){ this.socket=socket; this.mark=mark; setName("Client-"+mark); }
        void send(String msg){ if(out!=null) out.println(msg); }

        public void run(){
            try{
                out=new java.io.PrintWriter(new java.io.OutputStreamWriter(socket.getOutputStream(),"UTF-8"),true);
                in =new java.io.BufferedReader(new java.io.InputStreamReader(socket.getInputStream(),"UTF-8"));
                send("ASSIGNED "+mark);
                send("PORT "+PORT);
                send("MSG Conectado como "+mark+". Aguardando outro jogador...");
                if(clients.size()==2) sendFullStateToAll();
                String line;
                while((line=in.readLine())!=null){
                    line=line.trim();
                    if(line.startsWith("MOVE")){
                        String[] parts=line.split("\\s+"); if(parts.length!=3) continue;
                        int r,c; try{ r=Integer.parseInt(parts[1]); c=Integer.parseInt(parts[2]); }catch(NumberFormatException ex){ continue; }
                        synchronized(lock){
                            if(mark!=currentPlayer){ send("MSG Não é seu turno."); continue; }
                            if(!isValidMove(r,c)){ send("MSG Jogada inválida."); continue; }
                            board[r][c]=mark;
                            broadcast("BOARD "+boardAsString());
                            if(checkWin(mark)){
                                if(mark=='X') xWins++; else oWins++;
                                broadcast("WIN "+mark);
                                broadcast("SCORE "+xWins+" "+oWins+" "+draws);
                                for(ClientHandler ch:clients){ if(ch.mark==mark) ch.send("MSG Você venceu!"); else ch.send("MSG Você perdeu!"); }
                                resetBoard(); nextPlayer();
                                broadcast("BOARD "+boardAsString());
                                broadcast("TURN "+currentPlayer);
                                broadcast("MSG Nova rodada! Vez de "+currentPlayer);
                            }else if(isBoardFull()){
                                draws++; broadcast("DRAW"); broadcast("SCORE "+xWins+" "+oWins+" "+draws);
                                for(ClientHandler ch:clients) ch.send("MSG Empate! Nova rodada começará.");
                                resetBoard(); nextPlayer();
                                broadcast("BOARD "+boardAsString()); broadcast("TURN "+currentPlayer);
                                broadcast("MSG Nova rodada! Vez de "+currentPlayer);
                            }else{
                                nextPlayer(); broadcast("TURN "+currentPlayer); broadcast("MSG Vez de "+currentPlayer);
                            }
                        }
                    }
                }
            }catch(java.io.IOException e){
                System.err.println("Cliente "+mark+" desconectou: "+e.getMessage());
            }finally{
                try{ socket.close(); }catch(java.io.IOException ignored){}
                removeClient(this);
            }
        }
    }
}
